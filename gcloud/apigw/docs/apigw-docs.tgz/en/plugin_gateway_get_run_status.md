### Functional description

Poll the status of a plugin gateway run. This endpoint is used by the `uniform_api v4.0.0` polling contract.

#### Interface Parameters

| Field | Type | Required | Description |
|------|------|------|------|
| `task_tag` | `string` | YES | run identifier, equal to `open_plugin_run_id` |

### Request Example

```text
GET /apigw/plugin-gateway/runs/status/?task_tag=4f3c2b1a0d9e8f7766554433221100aa
```

### Return Result Example

```json
{
  "result": true,
  "data": {
    "status": "SUCCEEDED",
    "outputs": {
      "job_instance_id": 1001
    },
    "error_message": ""
  },
  "code": 0,
  "trace_id": "xxx"
}
```

### Return Result Description

| Field | Type | Description |
|------|------|------|
| `data.status` | `string` | run status |
| `data.outputs` | `object` | output payload |
| `data.error_message` | `string` | error message when failed |

### Status Values

`status` can be `CREATED`, `RUNNING`, `WAITING_CALLBACK`, `SUCCEEDED`, `FAILED`, or `CANCELLED`. `RUNNING` is the value exposed by `polling.running_tag` in plugin detail.
