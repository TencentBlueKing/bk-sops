### Function description

Batch modify the webhook configuration of templates

### Request parameters

#### Interface parameters

| Field          | Type       | Required | Description                                                                          |
|----------------|------------|----------|--------------------------------------------------------------------------------------|
| endpoint       | string     | 是        | Webhook request address                                                              |
| events         | list       | 是        | Subscribe to events                                                                  |
| extra_info     | dict       | 否        | Additional parameters include authentication, request headers, and retry information |
| enable_webhook | bool       | 否        | Webhook configuration toggle is enabled by default                                   |
| template_ids   | list       | 是        | List of template IDs that need to be modified                                        |

#### Events: Current subscription events task_failed (task failed) and task_finished (task completed)

### Example of request parameters

```
{
     "endpoint": "https://xxx.com",
     "events": ["*"],
     "extra_info": {
          "authorization": {
               "type": "basic",  # bearer:token认证，basic：密码认证
               "username": "xxx",
               "password": "xxx",
               "token": "xxx"
          },
          "headers": [
               {
                    "key": "Content-Type",
                    "value": "application/json",
                    "doc": ""
               }
          ],
          "timeout": 10,
          "retry_times": 2,
          "interval": 60
     },
     "template_ids": [1]
}
```

Close and clear all webhook configurations for the specified template
```json

{
   "enable_webhook": false,
   "template_ids": [1, 2]
}
```

### Return the result example

```
{
    "result": true,
    "message": "success",
    "code": 0,
    "trace_id": "00-3ada3cec713520ede2ab03b156d1a33d-66b28b7e5e7f59fe-01"
}
```

### Return the result parameter description

| Field         | Type      | Description             |
|---------------|-----------|-------------------------|
| result        | bool      | true/false 操作是否成功       |
| message       | string    | result=false 时错误信息      |
| trace_id      | string    | open telemetry trace_id |